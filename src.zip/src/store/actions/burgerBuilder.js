import * as actionTypes from "./actionTypes";
import axios from "../../axios-orders";

export const addIngredient=(name)=>{
    return{
        type:actionTypes.ADD_INGREDINT,
        ingredientName:name
    }

}
export const removeIngredient=(name)=>{
    return{
        type:actionTypes.REMOVE_INGREDINT,
        ingredientName:name
    }

}
export const setIngredients=(ingredients)=>{
    return{
        type:actionTypes.SET_INGREDINTS,
        ingredients:ingredients

    };
}

export const fetchIngredientsFailed=()=>{
    return{
        type:actionTypes.FETCH_INGREDINTS_FAILED
    };
}

export const initIngredients=()=>{
    return dispatch=>{
        axios
        .get(
          "https://react-burger-builder-2735d-default-rtdb.firebaseio.com/ingredients.json"
        )
        .then((response) => {
            dispatch(setIngredients(response.data))
          
        })
        .catch(error=>{
         dispatch(fetchIngredientsFailed());
        });

    }
}