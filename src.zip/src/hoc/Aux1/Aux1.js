const aux1=(props)=>(props.children);

export default aux1;