import React from "react";
import {connect} from "react-redux";
import Aux1 from "../Aux1/Aux1";
import "./Layout.css";
import Toolbar from "../../components/Navigation/Toolbar/Toolbar";
import SideDrawer from "../../components/Navigation/SideDrawer/SideDrawer";
import { Component } from "react";


class Layout extends Component {
  state={
    showSideDrawer:false
  }
  SideDrawerClosedHandler=()=>{
    this.setState({showSideDrawer:false});
  }
  SidedrawerToggleHandler=()=>{
   
    this.setState((prevState)=>{
      return {showSideDrawer:!prevState.showSideDrawer};
    })
  }
  render() {
    return (
      <Aux1>
        <Toolbar 
        isAuth={this.props.isAuthenticated}
        drawerToggleClicked={this.SidedrawerToggleHandler}/>
        <SideDrawer isAuth={this.props.isAuthenticated} open={this.state.showSideDrawer} closed={this.SideDrawerClosedHandler} />

        <main className="Content">{this.props.children}</main>
      </Aux1>
    );
  }
}
const mapStateToProps=state=>{
 return{
   isAuthenticated:state.auth.token != null,

 }
}
export default connect(mapStateToProps)(Layout);
